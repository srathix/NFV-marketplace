import subprocess

cid = int(input("Enter your id  "))
cid1 = str(cid)
subprocess.check_call(["/media/avivek/New Volume/Today/miner1/3_commSPReg.sh",name,cid1])