import subprocess

subprocess.check_call(["/media/avivek/New Volume/Today/miner1/0_registerOrg.sh",'false','true','false',nameOrg])