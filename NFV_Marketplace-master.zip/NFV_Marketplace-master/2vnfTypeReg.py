import subprocess

vid = int(input("What's your id? "))
vid1 = str(vid)
subprocess.check_call(["/media/avivek/New Volume/Today/miner1/2_vnfTypeReg.sh",name,details,vid1])